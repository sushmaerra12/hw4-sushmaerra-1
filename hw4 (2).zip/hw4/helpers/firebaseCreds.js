// Your web app's Firebase configuration
export const firebaseConfig = {
    apiKey: "AIzaSyAdzJmndNfwccusNkPiG-YdbDI1PxHyMoA",
    authDomain: "geocalculator-bedbd.firebaseapp.com",
    databaseURL: "https://geocalculator-bedbd-default-rtdb.firebaseio.com",
    projectId: "geocalculator-bedbd",
    storageBucket: "geocalculator-bedbd.appspot.com",
    messagingSenderId: "1066049882294",
    appId: "1:1066049882294:web:a7729ae691a70e2523be17"
};